// Package customizations provides the implementation of customizations for
// the ec2 module.
package customizations
